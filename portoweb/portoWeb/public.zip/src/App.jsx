import './App.css'
import Home from './pages/home'

function App() {
  return (
    <div>
      <Home />
    </div>
  )
}

export default App
